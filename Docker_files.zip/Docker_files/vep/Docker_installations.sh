## Follow the below instructions for VEP installations

mkdir $HOME/vep_data
sudo chmod 777 -R $HOME/vep_data
docker pull ensemblorg/ensembl-vep
docker run -t -i -v $HOME/vep_data:/data ensemblorg/ensembl-vep INSTALL.pl -a c
sudo docker run -t -i -v $HOME/vep_data:/data ensemblorg/ensembl-vep INSTALL.pl -a cf -s homo_sapiens -y GRCh38
